const ProfileDetailModel = require('../model/profileDetails');


exports.postProfileDetail = async (req,res,next) =>{
    try{
        let data = req.body;
        const profile = await ProfileDetailModel.create(data);

        if(profile) {
            return res.status(200).json({
                message : "Profile Detail Create Successfully....",
                hasError: false
            })
        }else {
            return res.status(400).json({
                message : "Profile Detail Not Create",
                hasError:true
            })
        }
    }catch(error) {
        console.log("===========Profile Detail Post Error===============",error);
    }
}