const NFT = require('../model/createNFT');

exports.postNFT = async (req,res,next) =>{
    try{
        let data = req.body;
        const nft = await NFT.create(data);
        if(nft) {
            return res.status(200).json({
                message:"NFT Create Successfully....",
                hasError:false
            })
        }else {
            return res.status(400).json({
                message:"NFT not creating.....!",
                hasError:true
            })
        }

    }catch(error) {
        console.log("============NFT post error==============",error);
    }
};
exports.getAllNFT = async (req,res,next) =>{
    try{
        let nfts = await NFT.fetchAll();
        const currentDate = new Date;
        const storeNFT =[];
        nfts.forEach((x) => {
            if (x.auctionStartDate <= currentDate && x.auctionEndDate >= currentDate){
                storeNFT.push(x);
            }
        })
        if (nfts) {
            return res.status(200).json({
                message : "Get All NFT Successfully......",
                hasError: false,
                "results" : storeNFT
            })
        }else{
            return res.status(400).json({
                message : "Not Get NFT",
                hasError : true,
                "results" : []
            })
        }
    }catch(error) {
        console.log("===========Get All NFT Error==========",error);
    }
}