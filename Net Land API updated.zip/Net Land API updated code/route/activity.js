const express = require ('express');
const VerifyToken = require('../middleware/auth');
const router = express.Router();
const ActivityController = require('../controller/activity');

router.post("/activity",VerifyToken.auth,ActivityController.postActivity);

router.get("/activites",VerifyToken.auth,ActivityController.getAllActivites);
module.exports = router;