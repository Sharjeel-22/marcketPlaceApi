const express = require('express');
const VerifyToken = require('../middleware/auth');
const UpdatePasswordController = require('../controller/updatePassword');

const router = express.Router();

router.post("/password",VerifyToken.auth,UpdatePasswordController.postPassword);

router.put("/change",VerifyToken.auth,UpdatePasswordController.updatePassword);

module.exports = router;