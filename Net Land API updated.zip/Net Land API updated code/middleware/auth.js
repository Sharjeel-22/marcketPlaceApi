const JWT = require('jsonwebtoken');
const minting = require('../model/minting');
const User = require('../model/minting');

module.exports.auth = async (req,res,next) =>{
    try{
        //get token 
        const header = req.get("Authorization");
        if (!header || !header.startsWith('Bearer')) {
                return res.status(500).json({
                    HasError: true,
                    ResultMessages: "Unauthorization access: Token not found",
                });
            }
        
        //token verification step
        const token = header.split(" ")[1];
        const decoded = JWT.verify(token, process.env.JWT_SECRET);
    }catch(error) {
        return res.status(500).json({
        HasError: true,
        ResultMessages: "Unauthorization access: Invalid Token",
    })
}
    next();
}
